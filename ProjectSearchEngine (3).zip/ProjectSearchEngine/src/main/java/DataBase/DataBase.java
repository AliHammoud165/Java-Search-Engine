package DataBase;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import NLP.NLP;

import java.util.ArrayList;
import java.util.List;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;
import com.mongodb.client.result.DeleteResult;
public class DataBase {
    private String host;
    private int port;

    public void setHost(String host) {
        this.host = host;
    }

    public void setPort(int port) {
        this.port = port;
    }

    DataBase(int port, String host) {
        this.port = port;
        this.host = host;
    }

    public history_DB[] getDATA() {
        MongoClient mongoClient = MongoClients.create("mongodb://" + host + ":" + port);
        MongoDatabase database = mongoClient.getDatabase("History");
        MongoCollection<Document> collection = database.getCollection("history");

        List<history_DB> historyList = new ArrayList<>();

        MongoCursor<Document> cursor = collection.find().iterator();
        while (cursor.hasNext()) {
            Document doc = cursor.next();
            // Extracting search and results from the document
            String search = doc.getString("Search");
            String results = doc.getString("Results");

            // Creating a new history_DB object and adding it to the list
            history_DB history = new history_DB();
            history.setSearch(search);
            history.setResults(results);
            historyList.add(history);
        }

        cursor.close();
        mongoClient.close();

        return historyList.toArray(new history_DB[0]);
    }

    public void simentecSearch(String whatYouWant, history_DB DATA[]) {
        // Initialize variables to store the most similar document and its results
        String mostSimilarDocument = "";
        String mostSimilarResults = "";
        double maxSimilarity = Double.MIN_VALUE;

        // Initialize lists to store searches and results
        ArrayList<String> searchList = new ArrayList<>();
        ArrayList<String> resultList = new ArrayList<>();

        // Populate searchList and resultList with data from DATA
        for (history_DB document : DATA) {
            searchList.add(document.getSearch());
            resultList.add(document.getResults());
        }

        // Initialize NLP object
        NLP nlp = new NLP();

        // Use the search method from NLP to find the most similar document
        String[] result = nlp.search(whatYouWant, searchList);

        // Extract the most similar document and its similarity score from the result
        String mostSimilarDocumentAndScore = result[0];
        double similarity = Double.parseDouble(result[1]);

        // Parse the most similar document from the result
        mostSimilarDocument = mostSimilarDocumentAndScore.substring("Most similar document: ".length());

        // Find the index of the most similar document in searchList
        int index = searchList.indexOf(mostSimilarDocument);

        // Retrieve the most similar results from resultList using the index
        mostSimilarResults = resultList.get(index);

        // Print the most similar document and its results
        System.out.println("Most similar document: " + mostSimilarDocument);
        System.out.println("Results: " + mostSimilarResults);
        System.out.println("Similarity Score: " + similarity);
    }
}

public void updateDocument(String searchField, String searchValue, String updateField, String updateValue) {
    try (MongoClient mongoClient = MongoClients.create("mongodb://" + host + ":" + port)) {
        MongoDatabase database = mongoClient.getDatabase("History");
        MongoCollection<Document> collection = database.getCollection("history");

        // Creating filter and update documents
        UpdateResult result = collection.updateMany(Filters.eq(searchField, searchValue), 
                                                    Updates.set(updateField, updateValue));

        // Printing the result of the update operation
        System.out.println("Documents matched: " + result.getMatchedCount());
        System.out.println("Documents modified: " + result.getModifiedCount());
    }
}

public void deleteDocument(String field, String value) {
    try (MongoClient mongoClient = MongoClients.create("mongodb://" + host + ":" + port)) {
        MongoDatabase database = mongoClient.getDatabase("History");
        MongoCollection<Document> collection = database.getCollection("history");

        // Deleting documents based on a condition
        DeleteResult result = collection.deleteMany(Filters.eq(field, value));

        // Printing the result of the delete operation
        System.out.println("Documents deleted: " + result.getDeletedCount());
    }
}