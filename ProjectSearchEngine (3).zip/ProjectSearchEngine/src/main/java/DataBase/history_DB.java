package DataBase;


public class history_DB {

    String Search;
    String Results;

    public void setResults(String results) {
        Results = results;
    }

    public void setSearch(String search) {
        Search = search;
    }

    public String getResults() {
        return Results;
    }

    public String getSearch() {
        return Search;
    }
}
