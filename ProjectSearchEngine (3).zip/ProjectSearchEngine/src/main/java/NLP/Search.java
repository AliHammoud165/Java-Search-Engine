package NLP;

import Util.doc_data;
import java.util.ArrayList;

public class Search {
    ArrayList<doc_data> documents;
    String whatYouWant;

    public Search(ArrayList<doc_data> documents, String whatYouWant) {
        this.documents = documents;
        this.whatYouWant = whatYouWant;
    }

    public void simentecSearch() {
        NLP nlp = new NLP();
        String mostSimilarDocumentData = null;
        String mostSimilarDocumentSource = null;
        double maxSimilarity = Double.MIN_VALUE;

        for (doc_data doc : documents) {
            ArrayList<String> w = new ArrayList<>();
            w.add(doc.getData());

            String[] result = nlp.search(whatYouWant, w);
            double similarity = Double.parseDouble(result[1]);

            if (similarity > maxSimilarity) {
                maxSimilarity = similarity;
                mostSimilarDocumentData = doc.getData();
                mostSimilarDocumentSource = doc.getSource();
            }
        }

        if (mostSimilarDocumentData != null) {
            System.out.println("Most similar document data: " + mostSimilarDocumentData);
            System.out.println("Source: " + mostSimilarDocumentSource);
        } else {
            System.out.println("No documents found.");
        }
    }
}
