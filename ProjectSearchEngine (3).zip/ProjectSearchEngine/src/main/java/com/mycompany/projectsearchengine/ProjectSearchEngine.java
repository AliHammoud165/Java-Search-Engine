import java.io.IOException;
import java.util.ArrayList;
import NLP.NLP;
import NLP.Search;
import Util.doc_data;
import Util.WordDocumentReader;
import java.util.ArrayList;
public class ProjectSearchEngine {


        public static void main(String[] args) throws IOException {
            NLP nlp=new NLP();

            WordDocumentReader w=new WordDocumentReader();
            String s = w.readDocument("C:/Users/LapTop 1/OneDrive/Desktop/Ali Hammoud.docx");
            String F =w.readDocument("C:/Users/LapTop 1/OneDrive/Desktop/DATABASE Report (1).docx");

            ArrayList<doc_data> list1 = w.Split(s, "Ali Hammoud.docx");
            ArrayList<doc_data> list2 = w.Split(F, "DATABASE Report (1).docx");

            ArrayList<doc_data> mergedList = doc_data.merge(list1, list2);



            Search search = new Search(mergedList, "1.Sing-a: Artist ->Song (0,n->1,n) ");

            // Perform the simentecSearch
            search.simentecSearch();
        }
    }


