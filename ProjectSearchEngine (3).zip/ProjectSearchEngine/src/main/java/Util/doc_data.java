package Util;

import java.util.ArrayList;

public class doc_data {
    private String data;

   private String Source;

    public String getData() {
        return data;
    }

    public String getSource() {
        return Source;
    }

    public void setData(String data) {
        this.data = data;
    }

    public void setSource(String source) {
        Source = source;
    }

    public static ArrayList<doc_data> merge(ArrayList<doc_data> list1, ArrayList<doc_data> list2) {
        ArrayList<doc_data> mergedList = new ArrayList<>(list1);
        mergedList.addAll(list2);
        return mergedList;
    }
}
