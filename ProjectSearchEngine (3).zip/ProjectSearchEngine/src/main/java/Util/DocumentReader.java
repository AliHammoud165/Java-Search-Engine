package Util;

import java.io.IOException;
import java.util.ArrayList;

public interface DocumentReader {
    String readDocument(String filePath) throws IOException;

    default ArrayList<doc_data> Split(String doc, String source) {
        String[] contentLines = doc.split("\\n");
        ArrayList<doc_data> lines = new ArrayList<>();
        for (String line : contentLines) {
            doc_data data = new doc_data();
            data.setData(line);
            data.setSource(source); // Assuming "ali" is the default source
            lines.add(data);
        }
        return lines;
    }
}