package Util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import org.json.JSONObject;

public class JSONDocumentReader implements DocumentReader {
    @Override
    public String readDocument(String filePath) throws IOException {
        File jsonFile = new File(filePath);
        String content = new String(Files.readAllBytes(jsonFile.toPath()));
        JSONObject jsonObject = new JSONObject(content); // Use JSONObject for a simple JSON or JSONArray for a JSON array
        return jsonObject.toString(4); // Returns the JSON string with an indentation of 4 for better readability
    }
}
