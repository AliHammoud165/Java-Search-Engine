package Util;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import java.io.FileInputStream;

public class XMLDocumentReader implements DocumentReader {
    @Override
    public String readDocument(String filePath) throws IOException {
        File xmlFile = new File(filePath);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        StringBuilder sb = new StringBuilder();

        try (FileInputStream fis = new FileInputStream(xmlFile)) {
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(fis));
            doc.getDocumentElement().normalize();
            // Recursively traverse the document from the root node
            traverseXML(doc.getDocumentElement(), sb);
            return sb.toString();
        } catch (ParserConfigurationException | SAXException e) {
            throw new IOException("Error parsing XML document", e);
        }
    }

    private void traverseXML(Node node, StringBuilder sb) {
        // Handle the node content here, for example:
        sb.append(node.getNodeName()).append(": ").append(node.getTextContent().trim()).append("\n");

        if (node.hasChildNodes()) {
            NodeList nodeList = node.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node currentNode = nodeList.item(i);
                if (currentNode.getNodeType() == Node.ELEMENT_NODE) {
                    traverseXML(currentNode, sb);
                }
            }
        }
    }
}
